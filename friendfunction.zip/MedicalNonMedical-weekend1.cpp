#include<iostream>
#include<string.h>
using namespace std;
class Medical
{
	private:
		int rno;
		int marks;
		char* name;
	public:
		void setRno(int);
		int getRno();
		void setMarks(int);
		int getMarks();
		void setName(char*);
		char* getName();		
};
class NonMedical
{
	private:
		int rno;
		int marks;
		char* name;
	public:
		void setRno(int);
		int getRno();
		void setMarks(int);
		int getMarks();
		void setName(char*);
		char* getName();		
};

void Medical::setRno(int rno)
{
	this->rno = rno;
}
int Medical::getRno()
{
	return rno;
}
void Medical::setMarks(int marks)
{
	this->marks = marks;
}
int Medical::getMarks()
{
	return marks;
}
void Medical::setName(char* name)
{
	int l = strlen(name);
	this->name = new char[l+1];
	strcpy(this->name, name);
}
char* Medical::getName()
{
	return name;
}

void NonMedical::setRno(int rno)
{
	this->rno = rno;
}
int NonMedical::getRno()
{
	return rno;
}
void NonMedical::setMarks(int marks)
{
	this->marks = marks;
}
int NonMedical::getMarks()
{
	return marks;
}
void NonMedical::setName(char* name)
{
	int l = strlen(name);
	this->name = new char[l+1];
	strcpy(this->name, name);
}
char* NonMedical::getName()
{
	return name;
}
void compare(Medical, NonMedical);
main()
{
	Medical mObj;
	NonMedical nObj;
	
	int r, m;
	char* name;
	int len;
	cout<<endl<<"Enter Medical Student's Data: ";
	cout<<endl<<"Enter Roll No : ";
	cin>>r;	
	cout<<endl<<"Enter length of your name: ";
	cin>>len;
	name = new char[len+1];
	cout<<endl<<"Enter Name : ";
	cin>>name;	
	cout<<endl<<"Enter Marks : ";
	cin>>m;
	mObj.setRno(r);
	mObj.setMarks(m);
	mObj.setName(name);
	
	cout<<endl<<"Enter NonMedical Student's Data: ";
	cout<<endl<<"Enter Roll No : ";
	cin>>r;	
	cout<<endl<<"Enter length of your name: ";
	cin>>len;
	name = new char[len+1];
	cout<<endl<<"Enter Name : ";
	cin>>name;	
	cout<<endl<<"Enter Marks : ";
	cin>>m;
	nObj.setRno(r);
	nObj.setMarks(m);
	nObj.setName(name);
	
	compare(mObj, nObj);
}

void compare(Medical mObj, NonMedical nObj)
{
	cout<<endl<<endl<<"OUTPUT";
	
	cout<<endl<<"Medical Student's Data: ";
	cout<<endl<<"Roll No : "<<mObj.getRno();
	cout<<endl<<"Name : "<<mObj.getName();
	cout<<endl<<"Marks : "<<mObj.getMarks();
	
	cout<<endl<<endl<<"NonMedical Student's Data: ";
	cout<<endl<<"Roll No : "<<nObj.getRno();
	cout<<endl<<"Name : "<<nObj.getName();
	cout<<endl<<"Marks : "<<nObj.getMarks();
	
	cout<<endl<<endl;
	if(mObj.getMarks() > nObj.getMarks())
	{
		int diff = mObj.getMarks() - nObj.getMarks();
		cout<<mObj.getName()<<" secured "<<diff<<" marks more than "<<nObj.getName();
	}
	else if(mObj.getMarks() < nObj.getMarks())
	{
		int diff = nObj.getMarks() - mObj.getMarks();
		cout<<nObj.getName()<<" secured "<<diff<<" marks more than "<<mObj.getName();
	}
	else 
	{
		cout<<nObj.getName()<<" and "<<mObj.getName()<<" secured equal marks";
	}
}
