#include<iostream>
#include<string.h>
using namespace std;
class NonMedical;
class Medical
{
	private:
		int rno;
		int marks;
		char* name;
	public:
		void setRno(int);
		void setMarks(int);
		void setName(char*);
		friend void compare(Medical, NonMedical);
};
class NonMedical
{
	private:
		int rno;
		int marks;
		char* name;
	public:
		void setRno(int);
		void setMarks(int);
		void setName(char*);		
		friend void compare(Medical, NonMedical);
};

void Medical::setRno(int rno)
{
	this->rno = rno;
}
void Medical::setMarks(int marks)
{
	this->marks = marks;
}
void Medical::setName(char* name)
{
	int l = strlen(name);
	this->name = new char[l+1];
	strcpy(this->name, name);
}

void NonMedical::setRno(int rno)
{
	this->rno = rno;
}
void NonMedical::setMarks(int marks)
{
	this->marks = marks;
}
void NonMedical::setName(char* name)
{
	int l = strlen(name);
	this->name = new char[l+1];
	strcpy(this->name, name);
}
void compare(Medical, NonMedical);
main()
{
	Medical mObj;
	NonMedical nObj;
	
	int r, m;
	char* name;
	int len;
	cout<<endl<<"Enter Medical Student's Data: ";
	cout<<endl<<"Enter Roll No : ";
	cin>>r;	
	cout<<endl<<"Enter length of your name: ";
	cin>>len;
	name = new char[len+1];
	cout<<endl<<"Enter Name : ";
	cin>>name;	
	cout<<endl<<"Enter Marks : ";
	cin>>m;
	mObj.setRno(r);
	mObj.setMarks(m);
	mObj.setName(name);
	
	cout<<endl<<"Enter NonMedical Student's Data: ";
	cout<<endl<<"Enter Roll No : ";
	cin>>r;	
	cout<<endl<<"Enter length of your name: ";
	cin>>len;
	name = new char[len+1];
	cout<<endl<<"Enter Name : ";
	cin>>name;	
	cout<<endl<<"Enter Marks : ";
	cin>>m;
	nObj.setRno(r);
	nObj.setMarks(m);
	nObj.setName(name);

	compare(mObj, nObj);
}

void compare(Medical mObj, NonMedical nObj)
{
	cout<<endl<<endl<<"OUTPUT";
	
	cout<<endl<<"Medical Student's Data: ";
	cout<<endl<<"Roll No : "<<mObj.rno;
	cout<<endl<<"Name : "<<mObj.name;
	cout<<endl<<"Marks : "<<mObj.marks;
	
	cout<<endl<<endl<<"NonMedical Student's Data: ";
	cout<<endl<<"Roll No : "<<nObj.rno;
	cout<<endl<<"Name : "<<nObj.name;
	cout<<endl<<"Marks : "<<nObj.marks;
	
	
	
	cout<<endl<<endl;
	if(mObj.marks > nObj.marks)
	{
		int diff = mObj.marks - nObj.marks;
		cout<<mObj.name<<" secured "<<diff<<" marks more than "<<nObj.name;
	}
	else if(mObj.marks < nObj.marks)
	{
		int diff = nObj.marks - mObj.marks;
		cout<<nObj.name<<" secured "<<diff<<" marks more than "<<mObj.name;
	}
	else 
	{
		cout<<nObj.name<<" and "<<mObj.name<<" secured equal marks";
	}
}
